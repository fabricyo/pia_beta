import { optionTypes } from './types';
declare const options: optionTypes;
export { options };
