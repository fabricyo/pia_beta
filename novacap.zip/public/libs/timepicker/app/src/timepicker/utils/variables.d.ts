declare const name = "timepicker-ui";
declare const mouseEvents = "mousedown mouseup mousemove mouseleave mouseover";
declare const touchEvents = "touchstart touchmove touchend";
declare const allEvents: string;
declare const selectorActive = "active";
export { name, mouseEvents, touchEvents, allEvents, selectorActive };
